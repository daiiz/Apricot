

    Polymer({

      behaviors: [
        Polymer.IronControlState,
        Polymer.IronButtonState
      ],

      hostAttributes: {
        role: 'button'
      }
    });

  