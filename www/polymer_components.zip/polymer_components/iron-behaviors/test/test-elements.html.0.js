

  Polymer({

    is: 'test-control',

    behaviors: [
      Polymer.IronControlState
    ]

  });

