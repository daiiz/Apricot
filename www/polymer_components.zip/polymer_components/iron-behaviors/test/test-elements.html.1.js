

  Polymer({

    is: 'test-button',

    behaviors: [
      Polymer.IronControlState,
      Polymer.IronButtonState
    ],

    _buttonStateChanged: function() {

    }

  });

