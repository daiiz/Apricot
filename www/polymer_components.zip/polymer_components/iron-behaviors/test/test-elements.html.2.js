

  Polymer({

    is: 'nested-focusable',

    behaviors: [
      Polymer.IronControlState
    ]

  });

