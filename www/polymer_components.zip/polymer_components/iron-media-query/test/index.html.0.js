

      WCT.loadSuites([
        'basic.html'
      ]);

    