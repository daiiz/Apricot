

    WCT.loadSuites([
      'activate-event.html',
      'basic.html',
      'multi.html',
      'next-previous.html',
      'selected-attribute.html',
      'template-repeat.html',
      'content.html'
    ]);

  