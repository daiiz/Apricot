

  Polymer({

    is: 'test-content-element',

    properties: {

      selectable: String,

      selected: {
        type: String,
        notify: true
      }

    }

  });

