

  Polymer({

    is: 'test-fit',

    behaviors: [
      Polymer.IronFitBehavior
    ]

  });

