

  Polymer({

    is: 'simple-fit',

    behaviors: [
      Polymer.IronFitBehavior
    ]

  });

