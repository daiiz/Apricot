

  Polymer({

    is: 'x-resizable-in-shadow'

  });

