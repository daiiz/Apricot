

    WCT.loadSuites([
      'basic.html'
    ]);

  