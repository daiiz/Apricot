

  Polymer({

    is: 'x-app',

    behaviors: [
      Polymer.IronResizableBehavior
    ]
  });

