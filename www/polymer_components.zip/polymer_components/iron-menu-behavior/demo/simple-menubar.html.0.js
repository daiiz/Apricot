

(function() {

  Polymer({

    is: 'simple-menubar',

    behaviors: [
      Polymer.IronMenubarBehavior
    ]

  });

})();

