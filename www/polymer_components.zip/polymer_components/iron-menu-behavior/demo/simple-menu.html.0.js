

(function() {

  Polymer({

    is: 'simple-menu',

    behaviors: [
      Polymer.IronMenuBehavior
    ]

  });

})();

