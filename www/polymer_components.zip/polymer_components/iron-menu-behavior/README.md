# iron-menu-behavior

`Polymer.IronMenuBehavior` implements accessible menu behavior.
