

(function() {

  Polymer({

    is: 'test-menubar',

    behaviors: [
      Polymer.IronMenubarBehavior
    ]

  });

})();

