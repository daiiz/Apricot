

(function() {

  Polymer({

    is: 'test-menu',

    behaviors: [
      Polymer.IronMenuBehavior
    ]

  });

})();

