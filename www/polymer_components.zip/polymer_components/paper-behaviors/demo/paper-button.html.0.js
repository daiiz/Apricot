

    Polymer({
      is: 'paper-button',

      behaviors: [
        Polymer.PaperButtonBehavior
      ]
    });

  