
  Polymer({
    is: 'test-radio-button',

    behaviors: [
      Polymer.PaperInkyFocusBehavior
    ]
  });
