

    Polymer({

      is: 'test-button',

      behaviors: [
        Polymer.PaperButtonBehavior
      ]

    });

  