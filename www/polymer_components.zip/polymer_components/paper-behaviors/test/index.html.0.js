
    WCT.loadSuites([
      'paper-button-behavior.html',
      'paper-radio-button-behavior.html'
    ]);
  