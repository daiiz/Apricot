

      WCT.loadSuites([
        'paper-dialog.html'
      ]);

    