

(function() {

  Polymer({

    is: 'simple-overlay',

    behaviors: [
      Polymer.IronOverlayBehavior
    ]

  });

})();

