

(function() {

  Polymer({

    is: 'test-overlay',

    behaviors: [
      Polymer.IronOverlayBehavior
    ]

  });

})();

