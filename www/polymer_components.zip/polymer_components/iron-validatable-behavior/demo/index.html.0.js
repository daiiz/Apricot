

    document.querySelector('template[is="dom-bind"]').invalid = false;

  