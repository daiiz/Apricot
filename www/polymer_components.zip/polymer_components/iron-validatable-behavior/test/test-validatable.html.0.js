

  Polymer({

    is: 'test-validatable',

    behaviors: [
      Polymer.IronValidatableBehavior
    ]

  });
