

    suite('basic', function() {

      test('setting `invalid` sets `aria-invalid=true`', function() {
        var node = fixture('basic');
        node.invalid = true;
        assert.equal(node.getAttribute('aria-invalid'), 'true', 'aria-invalid is set');
        node.invalid = false;
        assert.isFalse(node.hasAttribute('aria-invalid'), 'aria-invalid is unset');
      });

    });

  