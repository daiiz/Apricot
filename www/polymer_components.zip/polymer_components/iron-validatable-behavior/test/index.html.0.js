

      /* no tests */
      WCT.loadSuites([
        'iron-validatable-behavior.html'
      ]);

    