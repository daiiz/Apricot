# iron-validatable-behavior
Implements an element validated with Polymer.IronValidatorBehavior

