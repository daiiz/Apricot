# iron-form-element-behavior
Behavior that allows an element to be tracked by an iron-form
