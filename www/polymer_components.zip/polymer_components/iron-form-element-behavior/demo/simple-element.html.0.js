

  Polymer({

    is: 'simple-element',

    extends: 'input',

    behaviors: [
      Polymer.IronFormElementBehavior
    ]

  });

