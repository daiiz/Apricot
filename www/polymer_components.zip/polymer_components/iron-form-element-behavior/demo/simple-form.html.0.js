

  Polymer({

    is: 'simple-form',

    extends: 'form',

    properties: {
      formElements: {
        type: Object,
        notify: true
      }
    },

    listeners: {
      'iron-form-element-register': '_elementRegistered'
    },

    ready: function() {
      this.formElements = [];
    },

    _elementRegistered: function(e) {
      this.formElements.push(e.target);
      this.fire('element-registered');
    }

  });

