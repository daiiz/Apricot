

    WCT.loadSuites([
      'iron-iconset-svg.html'
    ]);

  