
    WCT.loadSuites([
      'basic.html',
      'iron-meta.html'
    ]);
  