
    Polymer({
      is: 'x-progressbar',

      behaviors: [Polymer.IronRangeBehavior]
    });
  