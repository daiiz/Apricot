
    suite('defaults', function() {
      var c1;

      setup(function() {
        c1 = fixture('NoLabel');
      });

      test('check checkbox via click', function() {
        c1.addEventListener('click', function() {
          assert.isTrue(c1.getAttribute('aria-checked'));
          assert.isTrue(c1.checked);
          done();
        });
        MockInteractions.down(c1);
      });

      test('toggle checkbox via click', function() {
        c1.checked = true;
        c1.addEventListener('click', function() {
          assert.isFalse(c1.getAttribute('aria-checked'));
          assert.isFalse(c1.checked);
          done();
        });
        MockInteractions.down(c1);
      });

      test('disabled checkbox cannot be clicked', function() {
        c1.disabled = true;
        c1.addEventListener('click', function() {
          assert.isTrue(c1.getAttribute('aria-checked'));
          assert.isTrue(c1.checked);
          done();
        });
        MockInteractions.down(c1);
      });
    });

    suite('a11y', function() {
      var c1;
      var c2;

      setup(function() {
        c1 = fixture('NoLabel');
        c2 = fixture('WithLabel');
      });

      test('has aria role "checkbox"', function() {
        assert.isTrue(c1.getAttribute('role') == 'checkbox');
        assert.isTrue(c2.getAttribute('role') == 'checkbox');
      });

      test('checkbox with no label has no aria label', function() {
        assert.isTrue(!c1.getAttribute('aria-label'));
      });

      test('checkbox with a label sets an aria label', function() {
        assert.isTrue(c2.getAttribute('aria-label') == "Batman");
      });
    });
  