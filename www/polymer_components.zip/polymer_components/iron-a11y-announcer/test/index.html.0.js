
      WCT.loadSuites([
	      'iron-a11y-announcer.html'
      ]);
    