

    document.querySelector('[is=dom-bind]').getIconNames = function(iconset) {
      return iconset.getIconNames();
    };

  