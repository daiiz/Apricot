

    WCT.loadSuites([
      'iron-icon.html'
    ]);

  