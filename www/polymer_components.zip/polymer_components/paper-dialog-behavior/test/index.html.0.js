

      WCT.loadSuites([
        'paper-dialog-behavior.html'
      ]);

    