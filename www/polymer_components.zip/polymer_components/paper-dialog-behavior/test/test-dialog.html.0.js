

(function() {

  Polymer({

    is: 'test-dialog',

    behaviors: [
      Polymer.PaperDialogBehavior
    ]

  });

})();

