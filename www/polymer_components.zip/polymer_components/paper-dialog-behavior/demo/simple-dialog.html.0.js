

(function() {

  Polymer({

    is: 'simple-dialog',

    behaviors: [
      Polymer.PaperDialogBehavior
    ]

  });

})();

