
    suite('<paper-button>', function() {
      var button;

      setup(function() {
        button = fixture('TrivialButton');
      });

      test('can be raised imperatively', function(done) {
        button.raised = true;

        expect(button.hasAttribute('raised')).to.be.eql(true);

        Polymer.Base.async(function() {
          try {
            expect(button._elevation).to.be.eql(1);
            done();
          } catch (e) {
            done(e);
          }
        }, 1);
      });

      test('has aria role "button"', function() {
        expect(button.getAttribute('role')).to.be.eql('button');
      });

      test('can be disabled imperatively', function() {
        button.disabled = true;
        expect(button.getAttribute('aria-disabled')).to.be.eql('true');
        expect(button.hasAttribute('disabled')).to.be.eql(true);
      });

      test('can be triggered with space', function(done) {
        button.addEventListener('click', function() {
          done();
        });
        MockInteractions.pressSpace(button);
      });

      test('can be triggered with enter', function(done) {
        button.addEventListener('click', function() {
          done();
        });
        MockInteractions.pressEnter(button);
      });
    });
  