

      WCT.loadSuites([
        'paper-dialog-scrollable.html'
      ]);

    