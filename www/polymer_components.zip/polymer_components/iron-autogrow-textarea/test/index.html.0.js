
      WCT.loadSuites([
        'basic.html',
      ]);
    