
      // Load and run all tests (.html, .js) as one suite:
      WCT.loadSuites([
        'basic-test.html',
      ]);
    