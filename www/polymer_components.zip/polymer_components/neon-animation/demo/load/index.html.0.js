

      document.addEventListener('WebComponentsReady', function() {
        document.querySelector('full-page').show();
      });

    