

  Polymer({

    is: 'reprojected-pages',

    properties: {

      selected: {
        type: String,
        notify: true
      }

    }

  });

